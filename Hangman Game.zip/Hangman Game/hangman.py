import random
from Words import words
from hangman_visual import lives_visual_dict
import string

def get_valid_word(words):
    word=random.choice(words) # randomly chooses something from the list
    while " "in word or "-" in word:
        word=random.choice(words) # if the word contains spaces or hyphens, it chooses another one
        
    return word.upper()

def hangman_game():
    word=get_valid_word(words)
    word_letters=set(word) #letters in the word
    alphabet=set(string.ascii_uppercase)
    used_letters=set() #used letters in the word
    
    lives=7
    
    # Getting User Input
    while len(word_letters) > 0 and lives > 0:
        
        # Letters used
        # ''.join([a,b,b,d])---->'a b c d'
        print(f"You have {lives} lives left , and Used Letters is:", " ".join(sorted(used_letters)))
        
        # Current Word is "W _ O R D"
        
        # The letter if letter in used_letters else '-' part is a conditional expression that checks if the current letter is in the used_letters set. If it is, the letter itself is added to the new list; otherwise, a hyphen is added.
        word_list=[letter if letter in used_letters else '-' for letter in word]
        print(lives_visual_dict[lives])
        print("Current Word:", " ".join(word_list))
        
        guessed_letter=input("Guess a letter: ").upper()
        if guessed_letter in alphabet - used_letters: #checking guessed letter in alphabet by eliminating used letters
            used_letters.add(guessed_letter)
            if guessed_letter in word_letters: 
                word_letters.remove(guessed_letter)
            else:
                lives -= 1    # takes away lives if guess is wrong
                print("Letter is not in word")
        elif guessed_letter in used_letters:
            print("You've already guessed that letter. Try again.")
        else:
            print("Invalid Character , Please try again.")
            
    if lives == 0:
        print("You've run out of lives. The word was:", word.capitalize())  
        
    else:
        print("Congratulations! You've guessed the word is:", word.capitalize())     

hangman_game()
    


        